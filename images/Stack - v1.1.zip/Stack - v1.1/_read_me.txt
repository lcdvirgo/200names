Stack for Mac OS X by 34 Orange LLC
created by: Cory Shoaf 


---

Thanks for downloading Stack.

STACK LICENSE: 

This PSD template is provided as-is without any express or implied warranty.

ALLOWED
-Use the Stack template for personal and commercial projects royalty-free, WITHOUT attribution.
-Change the shape, size, color or style of elements based the terms of this agreement.


*NOTE*
34 Orange LLC is not affiliated with Apple. I created this PSD to help people design Mac software. I originally created this for myself for personal use and thought it would be fun to put it out in the world. 


Thanks again!


Contact us at info@34orange.com with questions or comments.



PictoFoundry is a product of 34 Orange LLC
 